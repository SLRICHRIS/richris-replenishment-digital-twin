# MQTT observation recorder starter kit

Run commands from this extracted directory. Use Python 3.10 or later.

```sh
python -m pip install -r backend_streamlit_and_telemetry/mqtt_recording_and_inventory_bridge/mqtt_recorder_network_dependencies.txt
python -m backend_streamlit_and_telemetry.mqtt_recording_and_inventory_bridge.mqtt_telemetry_recorder_and_inventory_publisher record --database warehouse-evidence.sqlite3
python -m unittest discover -s automated_software_checks/python_telemetry_service_checks -p 'test_*.py' -v
```

Set MQTT_HOST and MQTT_USER first; the password is requested privately.
Read [the complete setup guide](project_documentation/mqtt_sqlite_recorder_and_labview_adapter_setup.md).
The recorder archives observations. Physical robot commands require separate integration.

© 2026 S L RICHRIS. All rights reserved. Purely for educational purposes.
