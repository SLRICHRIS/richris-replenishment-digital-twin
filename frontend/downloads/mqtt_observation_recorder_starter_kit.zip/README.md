# MQTT observation recorder starter kit

Run commands from this extracted directory. Use Python 3.10 or later.

```sh
python -m pip install -r backend/edge/requirements.txt
python -m backend.edge.mqtt_observation_recorder record --database warehouse-evidence.sqlite3
python -m unittest discover -s tests/backend -p 'test_*.py' -v
```

Set MQTT_HOST and MQTT_USER first; the password is requested privately.
Read [the complete setup guide](docs/edge_observation_recorder_setup.md).
The recorder archives observations. Physical robot commands require separate integration.

© 2026 S L RICHRIS. All rights reserved. Purely for educational purposes.
